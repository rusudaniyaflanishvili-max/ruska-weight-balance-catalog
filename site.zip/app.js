
const C=window.CATALOG_CONFIG;
const API=C.api;
let products=C.fallbackProducts.map(x=>({...x,active:true,in_stock:true}));
let settings={
  delivery:{tbilisi:6,rustavi:7,region:8,village:10,free_delivery:false},
  contact:C.fallbackContact,
  promo_banner:{enabled:false,text:'',note:''}
};
let cart=JSON.parse(localStorage.getItem('wb_cart')||'{}');
let favorites=JSON.parse(localStorage.getItem('wb_favorites')||'[]');

const THEMES=[
['#18131c','#d9ae55','#fff4db','#3f2337','#fffaf0'],
['#f6ba32','#f47c3d','#fff3c5','#6f3d17','#fff9e6'],
['#5b2c24','#d7a764','#fff0dd','#4d241f','#fff9f1'],
['#17224b','#cda44f','#f7e8c0','#17224b','#fff9e7'],
['#d59620','#6b421d','#fff0bd','#3c2817','#fff9e7'],
['#9c3f7d','#efa4c8','#ffe7f1','#6b2856','#fff7fb'],
['#7d5546','#e4af8e','#fbe8dd','#5c3d32','#fff9f4'],
['#1e4d5e','#d5a94e','#f3e8cf','#1f4a55','#fffaf1'],
['#8e8233','#efd77a','#f8f1cf','#4b431d','#fffdf1'],
['#e483a6','#a4315d','#ffeaf1','#7a294f','#fff8fb'],
['#174c8f','#d33c55','#edf4ff','#153e74','#f9fbff'],
['#a5bd2e','#2b2e1c','#f5f8ce','#34381c','#fdffe9'],
['#c84972','#efa9c0','#fff0f5','#7d294a','#fff8fa'],
['#2e829f','#f0c34b','#eaf8ff','#205e73','#f8fdff'],
['#ae6647','#efc3a1','#fff0e7','#6b3c2b','#fff9f6']
];
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=n=>`${Number(n||0).toFixed(0)} ₾`;
const priceOf=p=>p.promo_active&&Number(p.promo_price)>0?Number(p.promo_price):Number(p.sale_price||0);
const productBySlug=s=>products.find(p=>p.slug===s);
const img=u=>u||'';
const isFav=s=>favorites.includes(s);

function pageTemplate(p,i){
  const t=THEMES[i%THEMES.length],price=priceOf(p);
  const old=p.promo_active&&Number(p.old_price)>0?`<span class="old">${money(p.old_price)}</span><span class="badge">აქცია</span>`:'';
  const secondary=p.image_url_2?`<img class="secondary" src="${esc(img(p.image_url_2))}" alt="${esc(p.name)} მეორე ფოტო">`:'';
  const canBuy=price>0&&p.in_stock!==false;
  const wa=(settings.contact?.whatsapp||'577049828').replace(/\D/g,'');
  const intl=wa.startsWith('995')?wa:`995${wa}`;
  const waText=encodeURIComponent(`გამარჯობა, მინდა შეკვეთა:\n${p.name}\nფასი: ${price?money(price):'მოთხოვნით'}`);
  return `<section class="sheet product-sheet" data-slug="${esc(p.slug)}">
    <div class="product-paper" style="--a:${t[0]};--b:${t[1]};--c:${t[2]};--accent:${t[3]};--light:${t[4]}">
      <div class="product-top"><span class="brand-small">წონის ბალანსის ფორმულა</span><span class="page-count">${i+1} / ${products.length}</span></div>
      <button class="heart ${isFav(p.slug)?'active':''}" onclick="toggleFav('${esc(p.slug)}',event)">♥</button>
      <div class="product-layout">
        <div class="photo-box"><img src="${esc(img(p.image_url))}" alt="${esc(p.name)}">${secondary}</div>
        <div class="info-card">
          <div class="kicker"><span>${esc(p.category||'')}</span>${esc(p.brand||'')}</div>
          <h2>${esc(p.name)}</h2>
          <p class="summary">${esc(p.short_description||'')}</p>
          <div class="price-line"><span class="price">${price?money(price):'ფასი მოთხოვნით'}</span>${old}</div>
          <div class="detail-grid">
            <div class="detail"><b>შეფუთვა</b><p>${esc(p.pack_info||'ინფორმაცია შეფუთვაზე')}</p></div>
            <div class="detail"><b>გამოყენება</b><p>${esc(p.usage||'გამოიყენეთ ეტიკეტის მიხედვით')}</p></div>
            <div class="detail full"><b>შემადგენლობა</b><p>${esc(p.ingredients||'გადაამოწმეთ ეტიკეტზე')}</p></div>
            <div class="detail full warn"><b>გაფრთხილება</b><p>${esc(p.warning||'18+. გაეცანით ეტიკეტს.')}</p></div>
          </div>
          <div class="product-actions">
            <button class="add" ${canBuy?'':'disabled'} onclick="addToCart('${esc(p.slug)}')">${canBuy?'კალათაში დამატება':'ფასი მოთხოვნით'}</button>
            <a class="product-wa" href="https://wa.me/${intl}?text=${waText}" target="_blank" rel="noopener">WhatsApp</a>
          </div>
        </div>
      </div>
    </div>
  </section>`;
}
function renderPages(){
  const book=$('book'); book.querySelectorAll('.product-sheet').forEach(n=>n.remove());
  products.sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)).forEach((p,i)=>book.insertAdjacentHTML('beforeend',pageTemplate(p,i)));
  updateNav(); updateSocial(); updatePromo(); updateSchemas();
  const hash=new URLSearchParams(location.hash.replace(/^#/,''));
  const slug=hash.get('product'); if(slug)setTimeout(()=>jumpTo(slug,false),60);
}
function updateSchemas(){
  const base=location.origin.startsWith('http')?location.origin:'https://ruska-weight-balance-catalog.vercel.app';
  const data={"@context":"https://schema.org","@type":"ItemList","name":"წონის ბალანსის ფორმულა — პროდუქტები",
    "itemListElement":products.map((p,i)=>({"@type":"ListItem","position":i+1,"url":`${base}/product/${p.slug}`,
      "item":{"@type":"Product","name":p.name,"image":p.image_url?.startsWith('http')?p.image_url:`${base}/${p.image_url}`,
      "description":p.short_description||'', "brand":{"@type":"Brand","name":p.brand||''},
      ...(priceOf(p)>0?{"offers":{"@type":"Offer","priceCurrency":"GEL","price":String(priceOf(p)),"availability":p.in_stock===false?"https://schema.org/OutOfStock":"https://schema.org/InStock"}}:{})}}))
  };
  $('productsSchema').textContent=JSON.stringify(data);
}
async function loadLive(){
  try{
    const r=await fetch(API); const d=await r.json();
    if(d.ok&&d.products?.length){
      const local=new Map(C.fallbackProducts.map(p=>[p.slug,p]));
      products=d.products.map(p=>({...local.get(p.slug),...p}));
      settings={...settings,...(d.settings||{})};
      renderPages(); refreshCart(); renderPlanSelect();
    }
  }catch(e){console.warn('offline mode')}
}
function currentIndex(){return Math.round($('book').scrollLeft/$('book').clientWidth)}
function go(n){const max=$('book').children.length-1;n=Math.max(0,Math.min(max,n));$('book').scrollTo({left:n*$('book').clientWidth,behavior:'smooth'})}
function updateNav(){const n=currentIndex();$('indicator').textContent=n===0?'საფარი':`${n} / ${products.length}`;$('prevBtn').disabled=n===0;$('nextBtn').disabled=n>=products.length}
function jumpTo(slug,setHash=true){const s=document.querySelector(`[data-slug="${CSS.escape(slug)}"]`);if(!s)return;$('book').scrollTo({left:s.offsetLeft,behavior:'smooth'});if(setHash)history.replaceState(null,'',`#product=${encodeURIComponent(slug)}`)}
$('book').addEventListener('scroll',()=>{clearTimeout(window.__s);window.__s=setTimeout(updateNav,70)});
$('prevBtn').onclick=()=>go(currentIndex()-1);$('nextBtn').onclick=()=>go(currentIndex()+1);

function updateSocial(){
  const c=settings.contact||C.fallbackContact;
  const wa=String(c.whatsapp||'577049828').replace(/\D/g,'');const intl=wa.startsWith('995')?wa:`995${wa}`;
  $('whatsappBtn').href=`https://wa.me/${intl}`;$('moreWhatsApp').href=`https://wa.me/${intl}`;
  if(c.instagram){$('instagramBtn').href=c.instagram;$('moreInstagram').href=c.instagram}
  if(c.facebook){$('facebookBtn').href=c.facebook;$('moreFacebook').href=c.facebook}
  const d=settings.delivery||{};$('deliveryText').textContent=d.free_delivery?'მიწოდება: უფასო':`თბილისი ${d.tbilisi??6} ₾ • რუსთავი ${d.rustavi??7} ₾ • სხვა ქალაქები/რეგიონები ${d.region??8} ₾ • სოფლები ${d.village??10} ₾`;
}
function updatePromo(){const p=settings.promo_banner||{};if(p.enabled&&p.text){$('promoBar').textContent=p.text+(p.note?` • ${p.note}`:'');$('promoBar').classList.remove('hidden')}else $('promoBar').classList.add('hidden')}

function toggleFav(slug,e){e?.stopPropagation();favorites=isFav(slug)?favorites.filter(x=>x!==slug):[...favorites,slug];localStorage.setItem('wb_favorites',JSON.stringify(favorites));document.querySelectorAll(`[data-slug="${CSS.escape(slug)}"] .heart`).forEach(b=>b.classList.toggle('active',isFav(slug)))}
function addToCart(slug){const p=productBySlug(slug);if(!p||priceOf(p)<=0)return;cart[slug]=(cart[slug]||0)+1;persistCart();openOverlay('cart')}
function persistCart(){localStorage.setItem('wb_cart',JSON.stringify(cart));refreshCart()}
function changeQty(slug,d){cart[slug]=Math.max(0,(cart[slug]||0)+d);if(!cart[slug])delete cart[slug];persistCart()}
function removeItem(slug){delete cart[slug];persistCart()}
function refreshCart(){
  $('cartCount').textContent=Object.values(cart).reduce((a,b)=>a+b,0);
  const entries=Object.entries(cart);
  $('cartLines').innerHTML=entries.length?entries.map(([slug,q])=>{const p=productBySlug(slug);if(!p)return'';return `<div class="cart-line"><img src="${esc(p.image_url)}"><div><b>${esc(p.name)}</b><div>${money(priceOf(p))}</div><div class="qty"><button onclick="changeQty('${esc(slug)}',-1)">−</button><span>${q}</span><button onclick="changeQty('${esc(slug)}',1)">+</button></div></div><button class="remove" onclick="removeItem('${esc(slug)}')">✕</button></div>`}).join(''):'<div class="empty">კალათა ცარიელია</div>';
  updateTotals()
}
function productTotal(){return Object.entries(cart).reduce((s,[slug,q])=>{const p=productBySlug(slug);return s+(p?priceOf(p)*q:0)},0)}
function shipping(){const d=settings.delivery||{};if(d.free_delivery)return 0;return Number(d[$('zone').value]??0)}
function updateTotals(){const p=productTotal(),s=shipping();$('productTotal').textContent=money(p);$('shippingTotal').textContent=money(s);$('grandTotal').textContent=money(p+s)}
$('zone').addEventListener('change',updateTotals);

async function submitOrder(){
  if(!Object.keys(cart).length)return alert('კალათა ცარიელია');
  if(!$('consent').checked)return alert('მონიშნეთ თანხმობა შეკვეთის დასამუშავებლად');
  const items=Object.entries(cart).map(([slug,qty])=>({product_id:productBySlug(slug)?.id,qty})).filter(x=>x.product_id);
  const body={customer:$('customer').value,phone:$('phone').value,zone:$('zone').value,city:$('city').value,address:$('address').value,payment_method:$('payment').value,notes:$('notes').value,items};
  const btn=$('submitOrder');btn.disabled=true;btn.textContent='იგზავნება...';
  try{
    const r=await fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();
    if(!r.ok||!d.ok)throw new Error(d.error||'შეცდომა');
    $('successBox').className='result ok';
    $('successBox').innerHTML=`<b>შეკვეთა #${d.order_no} მიღებულია ✓</b><br>სულ: ${money(d.total)}${d.whatsapp_url?`<a class="wa-link" href="${d.whatsapp_url}" target="_blank">WhatsApp-ზე შეკვეთის გაგზავნა</a>`:''}<button class="copy-btn" id="copyCourier">კურიერის ტექსტის კოპირება</button>`;
    $('copyCourier').onclick=async()=>{await navigator.clipboard.writeText(d.courier_text||d.message||'');$('copyCourier').textContent='კოპირებულია ✓'};
    localStorage.setItem('last_order',JSON.stringify({order_no:d.order_no,phone:body.phone}));
    cart={};persistCart();
  }catch(e){$('successBox').className='result bad';$('successBox').textContent=e.message||'შეკვეთის გაგზავნა ვერ მოხერხდა'}finally{btn.disabled=false;btn.textContent='შეკვეთის დადასტურება'}
}
$('submitOrder').onclick=submitOrder;$('cartBtn').onclick=()=>openOverlay('cart');

// Overlays
const map={cart:'cartOverlay',plan:'planOverlay',verify:'verifyOverlay',order:'orderOverlay',more:'moreOverlay'};
function openOverlay(name){if(name==='catalog'){closeAll();go(1);return}closeAll();if(map[name])$(map[name]).classList.add('open');document.querySelectorAll('.dock-btn').forEach(b=>b.classList.toggle('active',b.dataset.open===name))}
function closeAll(){document.querySelectorAll('.overlay').forEach(x=>x.classList.remove('open'));document.querySelectorAll('.dock-btn').forEach(b=>b.classList.toggle('active',b.dataset.open==='catalog'))}
document.querySelectorAll('[data-open]').forEach(b=>b.onclick=()=>openOverlay(b.dataset.open));document.querySelectorAll('[data-close]').forEach(b=>b.onclick=closeAll);document.querySelectorAll('.overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)closeAll()}));

// Plan (local only)
const today=()=>new Date().toISOString().slice(0,10);
const readPlan=()=>JSON.parse(localStorage.getItem('wb_plan')||'{}');
const writePlan=p=>localStorage.setItem('wb_plan',JSON.stringify(p));
function renderPlanSelect(){$('planProduct').innerHTML=products.map(p=>`<option value="${esc(p.slug)}">${esc(p.name)}</option>`).join('');const p=readPlan();if(p.product)$('planProduct').value=p.product;if(p.start)$('planStart').value=p.start;if(p.waterGoal)$('waterGoal').value=p.waterGoal;renderPlan()}
function savePlan(){const p=readPlan();p.product=$('planProduct').value;p.start=$('planStart').value||today();p.waterGoal=Math.max(250,Number($('waterGoal').value||2000));p.days=p.days||{};writePlan(p);renderPlan()}
function dayState(p){p.days=p.days||{};p.days[today()]=p.days[today()]||{water:0,used:false,meal:''};return p.days[today()]}
function renderPlan(){const p=readPlan();if(!p.product){$('planDashboard').classList.add('hidden');return}$('planDashboard').classList.remove('hidden');const st=dayState(p);const start=new Date(p.start||today());const now=new Date(today());$('planDay').textContent=Math.max(1,Math.floor((now-start)/86400000)+1);$('waterNow').textContent=`${st.water||0} მლ / ${p.waterGoal||2000}`;$('markProduct').textContent=st.used?'✓ შესრულებულია':'✓ შესრულდა';$('mealNote').value=st.meal||'';let streak=0;Object.keys(p.days).sort().reverse().some(d=>{if(p.days[d].used){streak++;return false}return true});$('streakNow').textContent=`${streak} დღე`;$('weightHistory').textContent=(p.weights||[]).slice(-5).reverse().map(x=>`${x.date}: ${x.value} კგ`).join(' • ')}
$('savePlan').onclick=savePlan;$('markProduct').onclick=()=>{const p=readPlan(),s=dayState(p);s.used=!s.used;writePlan(p);renderPlan()};$('waterPlus').onclick=()=>{const p=readPlan(),s=dayState(p);s.water=(s.water||0)+250;writePlan(p);renderPlan()};$('waterMinus').onclick=()=>{const p=readPlan(),s=dayState(p);s.water=Math.max(0,(s.water||0)-250);writePlan(p);renderPlan()};$('addWeight').onclick=()=>{const v=Number($('weightInput').value);if(!(v>0))return;const p=readPlan();p.weights=p.weights||[];p.weights.push({date:today(),value:v});writePlan(p);$('weightInput').value='';renderPlan()};$('saveMeal').onclick=()=>{const p=readPlan(),s=dayState(p);s.meal=$('mealNote').value.trim();writePlan(p);renderPlan();$('saveMeal').textContent='შენახულია ✓';setTimeout(()=>$('saveMeal').textContent='ჩანაწერის შენახვა',1200)};

// Verify
$('verifyBtn').onclick=async()=>{const code=$('verifyCode').value.trim();if(code.length<4)return;const r=$('verifyResult');r.className='result';r.textContent='მოწმდება...';try{const x=await fetch(`${API}?action=verify&code=${encodeURIComponent(code)}`);const d=await x.json();r.className=`result ${d.verified?'ok':'bad'}`;r.innerHTML=d.verified?`<b>კოდი რეგისტრირებულია ✓</b><br>${esc(d.product?.name||'')}${d.note?`<br>${esc(d.note)}`:''}`:`<b>კოდი ვერ მოიძებნა</b><br>${esc(d.message||'')}`}catch(e){r.className='result bad';r.textContent='შემოწმება ვერ მოხერხდა'}};

// Order lookup
const last=JSON.parse(localStorage.getItem('last_order')||'{}');if(last.order_no)$('lookupOrder').value=last.order_no;if(last.phone)$('lookupPhone').value=last.phone;
$('lookupBtn').onclick=async()=>{const r=$('lookupResult');r.className='result';r.textContent='მოწმდება...';try{const x=await fetch(`${API}?action=order_status&order_no=${encodeURIComponent($('lookupOrder').value)}&phone=${encodeURIComponent($('lookupPhone').value)}`);const d=await x.json();if(!d.found){r.className='result bad';r.textContent=d.message||'შეკვეთა ვერ მოიძებნა';return}r.className='result ok';r.innerHTML=`<b>შეკვეთა #${d.order_no}</b><br>სტატუსი: <b>${esc(d.status_label)}</b><br>ჯამი: ${money(d.total)}`}catch(e){r.className='result bad';r.textContent='სტატუსის მიღება ვერ მოხერხდა'}};

renderPages();refreshCart();renderPlanSelect();loadLive();
