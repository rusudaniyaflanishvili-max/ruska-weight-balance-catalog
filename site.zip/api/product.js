
const API='https://uqrcflysqlghnyequdll.supabase.co/functions/v1/catalog-v2-api';
const e=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
module.exports=async(req,res)=>{
  try{
    const slug=String(req.query.slug||'').trim();
    const r=await fetch(API);const d=await r.json();const p=(d.products||[]).find(x=>x.slug===slug);
    if(!p){res.statusCode=404;return res.end('Product not found')}
    const origin=`https://${req.headers.host}`;
    const img=p.image_url?.startsWith('http')?p.image_url:`${origin}/${p.image_url}`;
    const price=p.promo_active&&Number(p.promo_price)>0?Number(p.promo_price):Number(p.sale_price||0);
    const wa=String(d.settings?.contact?.whatsapp||'577049828').replace(/\D/g,'');const intl=wa.startsWith('995')?wa:`995${wa}`;
    const schema={"@context":"https://schema.org","@type":"Product","name":p.name,"image":[img],"description":p.short_description||'',"brand":{"@type":"Brand","name":p.brand||''},...(price>0?{"offers":{"@type":"Offer","url":`${origin}/product/${encodeURIComponent(slug)}`,"priceCurrency":"GEL","price":String(price),"availability":p.in_stock===false?"https://schema.org/OutOfStock":"https://schema.org/InStock","itemCondition":"https://schema.org/NewCondition"}}:{})};
    const html=`<!doctype html><html lang="ka"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${e(p.name)} — წონის ბალანსის ფორმულა</title><meta name="description" content="${e(p.short_description||'')}"><link rel="canonical" href="${origin}/product/${e(slug)}"><meta property="og:type" content="product"><meta property="og:title" content="${e(p.name)}"><meta property="og:description" content="${e(p.short_description||'')}"><meta property="og:image" content="${e(img)}"><meta property="og:url" content="${origin}/product/${e(slug)}"><script type="application/ld+json">${JSON.stringify(schema).replace(/</g,'\\u003c')}</script><style>body{font-family:Arial,sans-serif;margin:0;background:#f6efe9;color:#281f29}.wrap{max-width:900px;margin:auto;padding:20px}.card{background:white;border-radius:24px;padding:20px;box-shadow:0 14px 45px rgba(0,0,0,.1)}img{max-width:100%;max-height:520px;display:block;margin:auto;object-fit:contain}h1{font-size:36px}.price{font-size:34px;font-weight:900}.btn{display:inline-block;padding:12px 16px;border-radius:13px;text-decoration:none;background:#1c9154;color:white;font-weight:900;margin-right:8px}.back{background:#2c2130}</style></head><body><div class="wrap"><div class="card"><img src="${e(img)}" alt="${e(p.name)}"><h1>${e(p.name)}</h1><p>${e(p.short_description||'')}</p>${price>0?`<div class="price">${price.toFixed(0)} ₾</div>`:''}<p><b>შეფუთვა:</b> ${e(p.pack_info||'')}</p><p><b>გამოყენება:</b> ${e(p.usage||'')}</p><p><b>შემადგენლობა:</b> ${e(p.ingredients||'')}</p><p><b>გაფრთხილება:</b> ${e(p.warning||'')}</p><a class="btn back" href="/#product=${encodeURIComponent(slug)}">კატალოგში ნახვა</a><a class="btn" href="https://wa.me/${intl}?text=${encodeURIComponent('გამარჯობა, მინდა შეკვეთა: '+p.name)}">WhatsApp შეკვეთა</a></div></div></body></html>`;
    res.setHeader('Content-Type','text/html; charset=utf-8');res.setHeader('Cache-Control','s-maxage=300, stale-while-revalidate=600');res.end(html)
  }catch(err){res.statusCode=500;res.end('Server error')}
}
