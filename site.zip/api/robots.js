
module.exports=(req,res)=>{const origin=`https://${req.headers.host}`;res.setHeader('Content-Type','text/plain; charset=utf-8');res.end(`User-agent: *\nAllow: /\nDisallow: /admin.html\nSitemap: ${origin}/sitemap.xml\n`)}
